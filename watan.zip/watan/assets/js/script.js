// When the document is ready
$(document).ready(function () {
  var navbarHeight = 100; // Height of the navbar
  var navigationLinks = $('.navbar a'); // Navigation links in the navbar

  // Handle click event on navigation links
  navigationLinks.on('click', function (event) {
    var targetId = $(this).attr('href'); // Get the target element's ID

    if (targetId === "#" || !targetId.startsWith("#")) {
      return; // If the target is "#" (empty), do nothing
    }

    event.preventDefault(); // Prevent default link behavior

    var offcanvasElement = document.getElementById('offcanvas'); // Get the offcanvas element
    var offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement); // Get the offcanvas instance

    if (offcanvas) {
      offcanvas.hide(); // Hide the offcanvas if it exists
    }

    var targetOffset = $(targetId).offset().top - navbarHeight; // Calculate the target offset

    // Animate scrolling to the target element
    $('html, body').animate({
      scrollTop: targetOffset
    }, 100);
  });

  // Handle scroll event on the document
  $(document).scroll(function () {
    var scrollPosition = $(document).scrollTop(); // Get the scroll position

    // Iterate over each navigation link
    navigationLinks.each(function () {
      var targetId = $(this).attr('href'); // Get the target element's ID

      if (targetId === "#" || !targetId.startsWith("#")) {
        return; // If the target is "#" (empty), do nothing
      }

      var targetOffset = $(targetId).offset().top - navbarHeight - 2; // Calculate the target offset
      var targetHeight = $(targetId).outerHeight(); // Get the target element's height
      var targetBottom = targetOffset + targetHeight; // Calculate the bottom position of the target element

      // Add or remove the 'active' class based on scroll position
      if (scrollPosition < targetBottom && scrollPosition >= targetOffset) {
        $(this).addClass('active'); // Add 'active' class to the navigation link

        var buttonText = $('.navbar').find('a[href="' + targetId + '"]').text(); // Get the text of the corresponding navigation link
        $('#navbar h2').text(buttonText); // Set the text of the heading in the navbar
      } else {
        $(this).removeClass('active'); // Remove 'active' class from the navigation link
      }
    });
  });

  $('#services .position-relative button').click(function(e) {
    e.preventDefault();

    $('#services .position-relative button.active').not($(this)).each(function() {
        $(this).removeClass('position-absolute');
        $(this).addClass('position-relative');
        $(this).addClass('h-100');
        $(this).removeClass('py-5');
        $(this).removeClass('active').css('z-index', '');
        $(this).find('p').addClass('d-none');
    });

    if ($(this).hasClass('active')) {
        $(this).removeClass('position-absolute');
        $(this).addClass('position-relative');
        $(this).removeClass('py-5');
        $(this).addClass('h-100');
        $(this).removeClass('active').css('z-index', '');
        $(this).find('p').addClass('d-none');
    } else {
        $(this).addClass('position-absolute');
        $(this).removeClass('position-relative');
        $(this).removeClass('h-100');
        $(this).addClass('py-5');
        $(this).addClass('active').css('z-index', '3');
        $(this).find('p').removeClass('d-none');
    }
});

  $('#faq .btn').click(function() {
    var $container = $(this).closest('.position-relative');
    var $card = $container.find('.card');

    $('#faq .card.position-absolute').not($card).each(function() {
        var $container = $(this).closest('.position-relative');
        var $card = $container.find('.card');

        // Toggle visibility and absolute positioning
        $card.find('.card-body .answer-title').toggleClass('d-none');
        $card.toggleClass('opened');
        $(this).find('i').removeClass('icon-arrow-up').addClass('icon-arrow-down');
    });

    var $container = $(this).closest('.position-relative');
    var $card = $container.find('.card');

    // Toggle visibility and absolute positioning
    $card.find('.card-body .answer-title').toggleClass('d-none');
    $card.toggleClass('opened');

    // Update the icon
    if ($card.hasClass('opened')) {
        $(this).find('i').removeClass('icon-arrow-down').addClass('icon-arrow-up');
    } else {
        $(this).find('i').removeClass('icon-arrow-up').addClass('icon-arrow-down');
    }
});




  // Initialize the first testimonials carousel
  $('#testimonials .center').eq(0).slick({
    infinite: true,
    rtl: true,
    autoplay: true,
    autoplaySpeed: 2000,
    centerMode: true,
    variableWidth: false,
    centerPadding: '9rem',
    slidesToShow: 2,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '6rem',
          slidesToShow: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '3rem',
          slidesToShow: 1
        }
      }
    ]
  });

  // Initialize the second testimonials carousel
  $('#testimonials .center').eq(1).slick({
    infinite: true,
    rtl: false,
    autoplay: true,
    autoplaySpeed: 2000,
    centerMode: true,
    variableWidth: false,
    centerPadding: '9rem',
    slidesToShow: 2,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '6rem',
          slidesToShow: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '3rem',
          slidesToShow: 1
        }
      }
    ]
  });

  $('#emailInput').on('input propertychange', function() {
    var subject = $(this).val();
    var mailtoUrl = 'mailto:info@watn.sa?subject=' + encodeURIComponent(subject);
    $('#emailLink').attr('href', mailtoUrl);
  });

  $('#emailLink').on('click', function(e) {
    var subject = $('#emailInput').val();
    if (subject.trim() === '') {
      e.preventDefault();
      alert('Please enter a subject.');
    }
  });
});








